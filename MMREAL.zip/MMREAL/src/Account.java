public class Account {
    public static int week;
    public static int day;
    public static int monthlyDeposit;
    public static int balance;
    public static int weeklyAmount;

    public Account(){

    }
    public void setDay(int dy){
        day=dy;
    }
    public void setWeek(int wk){
        week=wk;
    }
    public void spend(int amount){
        balance-=amount;
    }
    public void setBalance(int b){
        balance=b;
    }
    public void setWeeklyAmount(){
        monthlyDeposit=1000;
        weeklyAmount=monthlyDeposit/4;
    }
    public void setMonthlyDeposit(int md){
        monthlyDeposit=md+monthlyDeposit;
    }
    public int getMonthlyLeft(){
        return balance;
    }
    public int getWeeklyLeft(){
        int x=4-week; //weeks passed
        int y=balance-x*weeklyAmount;
        int z=y/((4-week)+1);
        return z;
    }
}