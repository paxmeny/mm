import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        Account x = new Account();
        int ans;
        int tmp;
        ans = 0;
        tmp = 0;
        System.out.println("Enter current balance and date");
        System.out.println("balance");
        ans = reader.nextInt();
        x.setBalance(ans);
        System.out.println("date:week");
        ans = reader.nextInt();
        x.setWeek(ans);
        System.out.println("date:day");
        ans = reader.nextInt();
        x.setDay(ans);
        boolean run = true;
        while (run == true) {
            System.out.println("1 = get balance");
            System.out.println("2 = get weekly amount left");
            System.out.println("3 - spend amount");
            System.out.println("Close");
            ans = reader.nextInt();
            System.out.println("Pass getWeeklyLeft");
            if (ans == 1) {
                tmp = x.getMonthlyLeft();
            } else if (ans == 2) {
                tmp = x.getWeeklyLeft();
            } else if (ans == 3) {
                System.out.println("Enter Amount");
                tmp = reader.nextInt();
                x.spend(tmp);
                tmp = x.getMonthlyLeft();
            }
            else run=false;
            System.out.println(tmp);
        }
    }
}
